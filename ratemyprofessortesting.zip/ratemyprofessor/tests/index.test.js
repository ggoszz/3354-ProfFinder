const { getProfessorData } = require("../src/index");
const axios = require("axios");

// Mock axios
jest.mock("axios");

// Test cases for getProfessorData
describe("getProfessorData", () => {
  it("should fetch and return professor data from RateMyProfessor URL", async () => {
    const mockData = "<html>mocked data here</html>";
    axios.get.mockResolvedValue({ data: mockData });

    const result = await getProfessorData("https://ratemyprofessor.com/professor-url");

    expect(result).toEqual({
      name: "Dr. Example",
      rating: 4.5,
      comments: ["Great teacher!, Always is available to help other students!"]
    });
  });

  it("should throw an error if data fetch fails", async () => {
    axios.get.mockRejectedValue(new Error("Fetch error"));

    await expect(getProfessorData("https://ratemyprofessor.com/professor-url")).rejects.toThrow(
      "Failed to fetch professor data"
    );
  });
});
