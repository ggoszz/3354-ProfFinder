const axios = require("axios");

function parseProfessorData(data) {
  // Mock parse implementation: Adjust to parse actual HTML data as needed
  return { name: "Dr. Example", rating: 4.5, comments: ["Great teacher!, Always is available to help other students!"] };
}

async function getProfessorData(url) {
  try {
    const response = await axios.get(url);
    const { data } = response;

    const professorData = parseProfessorData(data);
    return professorData;
  } catch (error) {
    throw new Error("Failed to fetch professor data");
  }
}

module.exports = { getProfessorData };
